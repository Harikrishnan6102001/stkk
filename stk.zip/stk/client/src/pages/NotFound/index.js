import React from "react";

import image2 from "../../img/image2.svg";

function NotFound (){
  
  return (<div class="error_container">  
      			<img src={image2} Style="height:90vh;width: 90vw;"/>
		</div>);
}

export default NotFound;