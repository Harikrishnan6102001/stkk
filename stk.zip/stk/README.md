# discussy
A website for sharing question. build on MERN stack

## Features 

<ol>
	<li>User can signin/singup</li>
	<li>User can reset his password</li>
	<li>User can change his name</li>
	<li>Only regisetered user can add question/answer</li>
	<li>User need to verify his mail to add question or answer</li>
	<li>User can write answer for his own question</li>
	<li>User can like question/answer</li>
	<li>If user delete the question all the answers will be deleted</li>
	<li>User can edit question/answer</li>
	<li>User can search question</li>
	<li>If user edit the question it will show edited</li>
	<li>User can sort the question by latest/old</li>
	<li>User can sort the answer by latest/old</li>
</ol>  


live website <a href="https://https://discussy.herokuapp.com/">click here </a>